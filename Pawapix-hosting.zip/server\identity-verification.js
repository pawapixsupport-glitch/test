const NIN_PATTERN = /^\d{11}$/;

function normalizeNin(value) {
  return typeof value === 'string' ? value.replace(/\s+/g, '').trim() : '';
}

function getVerificationConfig() {
  return {
    url: process.env.NIN_VERIFICATION_URL || '',
    apiKey: process.env.NIN_VERIFICATION_API_KEY || ''
  };
}

async function verifyNin({ nationalId, name, email }) {
  const nin = normalizeNin(nationalId);
  if (!NIN_PATTERN.test(nin)) {
    return { status: 'failed', reason: 'NIN must contain exactly 11 digits.' };
  }

  const { url, apiKey } = getVerificationConfig();
  if (!url || !apiKey) {
    return {
      status: 'unavailable',
      reason: 'NIN verification is not configured. Add NIN_VERIFICATION_URL and NIN_VERIFICATION_API_KEY.'
    };
  }

  try {
    const response = await fetch(url, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Content-Type': 'application/json',
        Authorization: `Bearer ${apiKey}`
      },
      body: JSON.stringify({ nin, name, email })
    });
    const data = await response.json().catch(() => ({}));
    const verified = response.ok && (data.verified === true || data.status === 'verified' || data.data?.verified === true);

    return {
      status: verified ? 'verified' : 'failed',
      reason: verified ? '' : data.message || data.error || 'The NIN could not be verified.'
    };
  } catch (error) {
    return { status: 'unavailable', reason: 'The NIN verification service could not be reached.' };
  }
}

module.exports = { normalizeNin, verifyNin };
